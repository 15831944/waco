// AutobuildToolbar.cpp: implementation of the AutobuildToolbar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "meccano.h"
#include "AutobuildToolbar.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

AutobuildToolbar::AutobuildToolbar() : CAcUiDockControlBar()
{

}

AutobuildToolbar::~AutobuildToolbar()
{

}
