// BayPropToolbarWnd.cpp : implementation file
//

#include "stdafx.h"
#include "meccano.h"
#include "BayPropToolbarWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// BayPropToolbarWnd

BayPropToolbarWnd::BayPropToolbarWnd()
{
}

BayPropToolbarWnd::~BayPropToolbarWnd()
{
}


BEGIN_MESSAGE_MAP(BayPropToolbarWnd, CWnd)
	//{{AFX_MSG_MAP(BayPropToolbarWnd)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// BayPropToolbarWnd message handlers
