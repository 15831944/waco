// KwikScafColours.h: interface for the CKwikScafColours class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KWIKSCAFCOLOURS_H__135B9FF8_7DF8_11D4_9FD4_0008C7999B1D__INCLUDED_)
#define AFX_KWIKSCAFCOLOURS_H__135B9FF8_7DF8_11D4_9FD4_0008C7999B1D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



class CKwikScafColours  
{
public:
	CKwikScafColours();
	virtual ~CKwikScafColours();

};

#endif // !defined(AFX_KWIKSCAFCOLOURS_H__135B9FF8_7DF8_11D4_9FD4_0008C7999B1D__INCLUDED_)
