#if !defined(AFX_BAYPROPTOOLBARWND_H__100ED043_4D47_11D4_9FB2_0008C7999B1D__INCLUDED_)
#define AFX_BAYPROPTOOLBARWND_H__100ED043_4D47_11D4_9FB2_0008C7999B1D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BayPropToolbarWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// BayPropToolbarWnd window

class BayPropToolbarWnd : public CWnd
{
// Construction
public:
	BayPropToolbarWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(BayPropToolbarWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~BayPropToolbarWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(BayPropToolbarWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BAYPROPTOOLBARWND_H__100ED043_4D47_11D4_9FB2_0008C7999B1D__INCLUDED_)
