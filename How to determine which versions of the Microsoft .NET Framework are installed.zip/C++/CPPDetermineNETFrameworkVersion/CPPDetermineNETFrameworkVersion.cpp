// CPPDetermineNETFrameworkVersion.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
using namespace System;
using namespace Microsoft::Win32;


int main()
{
	// Opens the registry key for the .NET Framework entry.
	RegistryKey ^ndpKey = RegistryKey::OpenBaseKey(RegistryHive::LocalMachine, RegistryView::Registry32)->OpenSubKey("SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\");
	for each (System::String ^versionKeyName  in ndpKey->GetSubKeyNames())
	{
		if (versionKeyName->StartsWith("v"))
		{
			RegistryKey ^versionKey = ndpKey->OpenSubKey(versionKeyName);
			String ^name = versionKey->GetValue("Version","")->ToString();
			String ^sp = versionKey->GetValue("SP", "")->ToString();
			String ^install = versionKey->GetValue("Install", "")->ToString();
			if (install == "") {
				Console::WriteLine(versionKeyName + "" + name);
			}
			else {
				if (sp != "" && install == "1")
				{
					Console::WriteLine(versionKeyName + "  " + name + "  SP" + sp);
				}

			}
			if (name != "")
			{
				continue;
			}
			for each (String ^subKeyName  in versionKey->GetSubKeyNames())
			{
				RegistryKey ^subKey = versionKey->OpenSubKey(subKeyName);
				name = subKey->GetValue("Version", "")->ToString();
				if (name != "")
					sp = subKey->GetValue("SP", "")->ToString();
				install = subKey->GetValue("Install", "")->ToString();
				if (install == "") //no install info, must be later.
					Console::WriteLine(versionKeyName + "  " + name);
				else
				{
					if (sp != "" && install == "1")
					{
						Console::WriteLine("  " + subKeyName + "  " + name + "  SP" + sp);
					}
					else if (install == "1")
					{
						Console::WriteLine("  " + subKeyName + "  " + name);
					}
				}
			}
		}
	}
	Console::WriteLine("Press any key to continue...");
	Console::ReadKey();
	return 0;
}

